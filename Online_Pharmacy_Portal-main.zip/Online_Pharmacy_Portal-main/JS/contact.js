/*function confirmSubmit() {
    if (confirm("Are you sure you want to sent this message?")) {
        // Code submit message
        alert(" Message sent successfully");
    } else {
        // User cancel message
        alert("Message does not sent !");
    }
 }*/