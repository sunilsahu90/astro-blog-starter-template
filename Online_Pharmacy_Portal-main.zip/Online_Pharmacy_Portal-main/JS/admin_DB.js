//IT23539990
function manage_Product()
{
    window.location.href = "addDelete_Product.php";
}