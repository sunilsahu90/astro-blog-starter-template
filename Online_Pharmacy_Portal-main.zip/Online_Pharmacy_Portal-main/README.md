<h1 align="center" id="title">Online Pharmacy Portal</h1>

<div align="center">
 <img src="./Preview/Screenshot 2024-10-10 at 1.02.21 PM.png" alt="Image" style="width: 80%;"/>
 <br>Homepage<br><br>
 <hr>
 <img src="./Preview/Screenshot 2024-10-10 at 1.02.40 PM.png" alt="Image" style="width: 80%;"/>
 <br>Products Page<br><br>
 <hr>
 <img src="./Preview/Screenshot 2024-10-10 at 1.03.00 PM.png" alt="Image" style="width: 80%;"/>
 <br>Admin Dashboard<br><br>
 <hr>
 <img src="./Preview/Screenshot 2024-10-10 at 1.03.12 PM.png" alt="Image" style="width: 80%;"/>
 <br>Contact Us page<br><br>
 <hr>
</div>

## Colour Palette

**Headings** = #111111 <br>
**Content** = #444444 <br>
**Buttons** = #0098DA

## User Logins

### Admin Login

**Username**: admin01
**Password**: mod123

### Manager Login

**Username**: manager01
**Password**: managerPass02

**Username**: manager02
**Password**: managerPass03

### Customer Login

**Username**: user01
**Password**: userPass01

**Username**: user02
**Password**: userPass02

## Contributors
[**Moditha Marasingha**](https://github.com/ModithaM) | 
[**Hasindu Chanuka**](https://github.com/hasindu1998) | 
[**Kulanya Lisaldi**](https://github.com/KulanyaLisaldi) | 
[**Deshan**](https://github.com/Deshan-z) | 
[**Medhani**](https://github.com/PabodaWA)
